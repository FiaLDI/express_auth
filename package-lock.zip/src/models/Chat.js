const chats = []; // Все чаты
const messages = {}; // Сообщения по ID чата (messages[chatId] = [...])